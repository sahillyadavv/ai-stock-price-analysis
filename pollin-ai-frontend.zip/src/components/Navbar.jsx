import { Link } from "react-router-dom";

export default function Navbar() {
  return (
    <nav style={{
      background: "#fff",
      borderBottom: "1px solid #e8e8e8",
      padding: "0 24px",
      height: 60,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      position: "sticky",
      top: 0,
      zIndex: 100,
    }}>
      <Link to="/" style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <div style={{
          background: "#00b386",
          color: "#fff",
          fontWeight: 700,
          fontSize: 18,
          padding: "4px 12px",
          borderRadius: 8,
          letterSpacing: 1,
        }}>
          Pollin AI
        </div>
        <span style={{ color: "#888", fontSize: 13 }}>Stock Analysis</span>
      </Link>

      <div style={{ display: "flex", gap: 24, fontSize: 14, color: "#444" }}>
        <Link to="/" style={{ fontWeight: 500 }}>Home</Link>
        <a href="http://127.0.0.1:8000/docs" target="_blank" rel="noreferrer">API Docs</a>
      </div>
    </nav>
  );
}
