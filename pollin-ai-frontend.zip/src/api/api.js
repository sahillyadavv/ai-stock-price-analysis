import axios from "axios";

const BASE = "http://127.0.0.1:8000/api";

export const fetchStock     = (symbol, period = "6mo") => axios.get(`${BASE}/stock/${symbol}?period=${period}`);
export const fetchPredict   = (symbol)                  => axios.get(`${BASE}/predict/${symbol}`);
export const fetchSentiment = (symbol)                  => axios.get(`${BASE}/sentiment/${symbol}`);
export const searchStocks   = (query)                   => axios.get(`${BASE}/search/${query}`);
