import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { searchStocks, fetchStock } from "../api/api";

const POPULAR = ["AAPL", "TSLA", "GOOGL", "MSFT", "NVDA", "INFY.NS", "RELIANCE.NS", "TCS.NS"];

function MiniCard({ symbol }) {
  const [data, setData] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    fetchStock(symbol, "1mo").then(r => setData(r.data)).catch(() => {});
  }, [symbol]);

  if (!data) return (
    <div style={cardStyle}>
      <div style={{ color: "#ccc", fontSize: 13 }}>Loading...</div>
    </div>
  );

  const first = data.history[0]?.close || 0;
  const last  = data.history[data.history.length - 1]?.close || 0;
  const change = ((last - first) / first * 100).toFixed(2);
  const up = change >= 0;

  return (
    <div style={cardStyle} onClick={() => navigate(`/stock/${symbol}`)}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <div style={{ fontWeight: 700, fontSize: 15 }}>{symbol.replace(".NS", "")}</div>
          <div style={{ color: "#888", fontSize: 12, marginTop: 2 }}>{data.name?.split(" ").slice(0, 2).join(" ")}</div>
        </div>
        <div style={{
          background: up ? "#e6f9f4" : "#fdeaea",
          color: up ? "#00b386" : "#eb5757",
          fontSize: 12, fontWeight: 600,
          padding: "3px 8px", borderRadius: 6,
        }}>
          {up ? "▲" : "▼"} {Math.abs(change)}%
        </div>
      </div>
      <div style={{ marginTop: 12, fontSize: 20, fontWeight: 700 }}>
        {data.currency === "INR" ? "₹" : "$"}{last.toLocaleString()}
      </div>
      <div style={{ color: "#888", fontSize: 12, marginTop: 2 }}>1 month</div>
    </div>
  );
}

const cardStyle = {
  background: "#fff",
  border: "1px solid #e8e8e8",
  borderRadius: 12,
  padding: 16,
  cursor: "pointer",
  transition: "box-shadow 0.2s",
  minWidth: 160,
};

export default function Home() {
  const [query, setQuery]     = useState("");
  const [results, setResults] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (query.length < 1) { setResults([]); return; }
    const t = setTimeout(() => {
      searchStocks(query).then(r => setResults(r.data)).catch(() => setResults([]));
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "32px 16px" }}>

      {/* Hero */}
      <div style={{ textAlign: "center", marginBottom: 40 }}>
        <h1 style={{ fontSize: 32, fontWeight: 800, color: "#1a1a1a" }}>
          AI-Powered Stock Analysis
        </h1>
        <p style={{ color: "#888", marginTop: 8, fontSize: 16 }}>
          Real-time prices · 7-day forecasts · Sentiment analysis
        </p>
      </div>

      {/* Search */}
      <div style={{ position: "relative", maxWidth: 500, margin: "0 auto 40px" }}>
        <input
          value={query}
          onChange={e => setQuery(e.target.value)}
          placeholder="Search stocks — AAPL, TCS, RELIANCE..."
          style={{
            width: "100%", padding: "14px 20px",
            border: "2px solid #e8e8e8", borderRadius: 12,
            fontSize: 15, outline: "none",
            transition: "border 0.2s",
          }}
          onFocus={e => e.target.style.borderColor = "#00b386"}
          onBlur={e  => e.target.style.borderColor = "#e8e8e8"}
        />

        {results.length > 0 && (
          <div style={{
            position: "absolute", top: "110%", left: 0, right: 0,
            background: "#fff", border: "1px solid #e8e8e8",
            borderRadius: 12, boxShadow: "0 8px 24px rgba(0,0,0,0.1)",
            zIndex: 50, overflow: "hidden",
          }}>
            {results.map(r => (
              <div
                key={r.symbol}
                onClick={() => { navigate(`/stock/${r.symbol}`); setQuery(""); setResults([]); }}
                style={{
                  padding: "12px 20px", cursor: "pointer",
                  display: "flex", justifyContent: "space-between",
                  borderBottom: "1px solid #f0f0f0",
                }}
                onMouseEnter={e => e.currentTarget.style.background = "#f8f9fa"}
                onMouseLeave={e => e.currentTarget.style.background = "#fff"}
              >
                <span style={{ fontWeight: 600 }}>{r.symbol}</span>
                <span style={{ color: "#888", fontSize: 13 }}>{r.name}</span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Popular Stocks */}
      <div>
        <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 16 }}>Popular Stocks</h2>
        <div style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
          gap: 16,
        }}>
          {POPULAR.map(s => <MiniCard key={s} symbol={s} />)}
        </div>
      </div>
    </div>
  );
}
