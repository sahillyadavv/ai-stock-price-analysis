import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid, ReferenceLine,
} from "recharts";
import { fetchStock, fetchPredict, fetchSentiment } from "../api/api";

const PERIODS = ["1mo", "3mo", "6mo", "1y"];

function Stat({ label, value }) {
  return (
    <div style={{ minWidth: 120 }}>
      <div style={{ color: "#888", fontSize: 12, marginBottom: 4 }}>{label}</div>
      <div style={{ fontWeight: 600, fontSize: 15 }}>{value ?? "—"}</div>
    </div>
  );
}

function SentimentBadge({ label, color, score }) {
  const bg    = color === "green" ? "#e6f9f4" : color === "red" ? "#fdeaea" : "#f0f0f0";
  const fg    = color === "green" ? "#00b386" : color === "red" ? "#eb5757" : "#888";
  const emoji = color === "green" ? "🟢" : color === "red" ? "🔴" : "⚪";
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 8,
      background: bg, color: fg,
      padding: "6px 14px", borderRadius: 20,
      fontWeight: 600, fontSize: 14,
    }}>
      {emoji} {label} ({score > 0 ? "+" : ""}{score})
    </div>
  );
}

export default function StockDetail() {
  const { symbol } = useParams();
  const navigate   = useNavigate();
  const [period, setPeriod]       = useState("6mo");
  const [stock, setStock]         = useState(null);
  const [predict, setPredict]     = useState(null);
  const [sentiment, setSentiment] = useState(null);
  const [loading, setLoading]     = useState(true);
  const [tab, setTab]             = useState("price");

  useEffect(() => {
    setLoading(true);
    setStock(null); setPredict(null); setSentiment(null);
    Promise.all([
      fetchStock(symbol, period),
      fetchPredict(symbol),
      fetchSentiment(symbol),
    ]).then(([s, p, sent]) => {
      setStock(s.data);
      setPredict(p.data);
      setSentiment(sent.data);
    }).catch(console.error)
      .finally(() => setLoading(false));
  }, [symbol, period]);

  if (loading) return (
    <div style={{ textAlign: "center", padding: 80, color: "#888" }}>
      <div style={{ fontSize: 40, marginBottom: 16 }}>📈</div>
      Loading {symbol}...
    </div>
  );

  if (!stock) return (
    <div style={{ textAlign: "center", padding: 80, color: "#eb5757" }}>
      Could not load data for {symbol}.
      <br />
      <button onClick={() => navigate("/")} style={{
        marginTop: 16, padding: "10px 20px",
        background: "#00b386", color: "#fff", borderRadius: 8,
      }}>Go Back</button>
    </div>
  );

  const first   = stock.history[0]?.close || 0;
  const last    = stock.history[stock.history.length - 1]?.close || 0;
  const change  = ((last - first) / first * 100).toFixed(2);
  const up      = parseFloat(change) >= 0;
  const curr    = stock.currency === "INR" ? "₹" : "$";

  // Combine history + forecast for combined chart
  const histData    = stock.history.map(h => ({ date: h.date, price: h.close }));
  const forecastData = predict?.predictions?.map(p => ({ date: p.date, forecast: p.price })) || [];
  const combinedData = [
    ...histData.slice(-30),
    ...forecastData,
  ];

  return (
    <div style={{ maxWidth: 900, margin: "0 auto", padding: "24px 16px" }}>

      {/* Back button */}
      <button onClick={() => navigate("/")} style={{
        background: "none", color: "#888", fontSize: 14,
        marginBottom: 16, display: "flex", alignItems: "center", gap: 4,
      }}>
        ← Back
      </button>

      {/* Header */}
      <div style={{
        background: "#fff", borderRadius: 16, padding: 24,
        border: "1px solid #e8e8e8", marginBottom: 16,
      }}>
        <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{
                background: "#00b386", color: "#fff",
                fontWeight: 700, fontSize: 16,
                padding: "6px 14px", borderRadius: 8,
              }}>{symbol.replace(".NS", "")}</div>
              <div style={{ color: "#888", fontSize: 14 }}>{stock.name}</div>
            </div>
            <div style={{ marginTop: 12, fontSize: 36, fontWeight: 800 }}>
              {curr}{last.toLocaleString()}
            </div>
            <div style={{
              marginTop: 6, display: "flex", alignItems: "center", gap: 8,
            }}>
              <span style={{ color: up ? "#00b386" : "#eb5757", fontWeight: 600, fontSize: 16 }}>
                {up ? "▲" : "▼"} {Math.abs(change)}%
              </span>
              <span style={{ color: "#888", fontSize: 13 }}>({period})</span>
              {sentiment && (
                <SentimentBadge
                  label={sentiment.overall_label}
                  color={sentiment.overall_color}
                  score={sentiment.overall_score}
                />
              )}
            </div>
          </div>

          {/* Stats */}
          <div style={{ display: "flex", gap: 24, flexWrap: "wrap" }}>
            <Stat label="52W High" value={`${curr}${stock["52w_high"]?.toLocaleString()}`} />
            <Stat label="52W Low"  value={`${curr}${stock["52w_low"]?.toLocaleString()}`} />
            <Stat label="P/E Ratio" value={stock.pe_ratio?.toFixed(1)} />
            <Stat label="Sector"   value={stock.sector} />
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
        {["price", "forecast", "sentiment"].map(t => (
          <button key={t} onClick={() => setTab(t)} style={{
            padding: "8px 20px", borderRadius: 20,
            background: tab === t ? "#00b386" : "#fff",
            color: tab === t ? "#fff" : "#444",
            border: "1px solid #e8e8e8",
            fontWeight: 600, fontSize: 14,
          }}>
            {t === "price" ? "📈 Price" : t === "forecast" ? "🔮 Forecast" : "📰 Sentiment"}
          </button>
        ))}
      </div>

      {/* Price Chart */}
      {tab === "price" && (
        <div style={{ background: "#fff", borderRadius: 16, padding: 24, border: "1px solid #e8e8e8" }}>
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
            <h2 style={{ fontSize: 16, fontWeight: 700 }}>Price History</h2>
            <div style={{ display: "flex", gap: 8 }}>
              {PERIODS.map(p => (
                <button key={p} onClick={() => setPeriod(p)} style={{
                  padding: "4px 12px", borderRadius: 6, fontSize: 13,
                  background: period === p ? "#00b386" : "#f0f0f0",
                  color: period === p ? "#fff" : "#444",
                  border: "none", fontWeight: 600,
                }}>
                  {p}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={stock.history}>
              <defs>
                <linearGradient id="priceGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor={up ? "#00b386" : "#eb5757"} stopOpacity={0.2}/>
                  <stop offset="95%" stopColor={up ? "#00b386" : "#eb5757"} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
              <XAxis dataKey="date" tick={{ fontSize: 11 }}
                tickFormatter={d => d.slice(5)} interval="preserveStartEnd"/>
              <YAxis tick={{ fontSize: 11 }} domain={["auto","auto"]}
                tickFormatter={v => `${curr}${v.toLocaleString()}`}/>
              <Tooltip formatter={(v) => [`${curr}${v}`, "Price"]}
                labelStyle={{ fontWeight: 600 }}/>
              <Area type="monotone" dataKey="close"
                stroke={up ? "#00b386" : "#eb5757"} strokeWidth={2}
                fill="url(#priceGrad)"/>
            </AreaChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Forecast Chart */}
      {tab === "forecast" && predict && (
        <div style={{ background: "#fff", borderRadius: 16, padding: 24, border: "1px solid #e8e8e8" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
            <h2 style={{ fontSize: 16, fontWeight: 700 }}>7-Day AI Forecast</h2>
            <div style={{ display: "flex", gap: 12 }}>
              <div style={{
                background: predict.trend === "bullish" ? "#e6f9f4" : "#fdeaea",
                color: predict.trend === "bullish" ? "#00b386" : "#eb5757",
                padding: "4px 12px", borderRadius: 20, fontWeight: 600, fontSize: 13,
              }}>
                {predict.trend === "bullish" ? "🚀 Bullish" : "📉 Bearish"} {predict.change_7d_pct > 0 ? "+" : ""}{predict.change_7d_pct}%
              </div>
              <div style={{
                background: "#f0f0f0", color: "#444",
                padding: "4px 12px", borderRadius: 20, fontWeight: 600, fontSize: 13,
              }}>
                Confidence: {predict.confidence}%
              </div>
            </div>
          </div>

          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={combinedData}>
              <defs>
                <linearGradient id="histGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#888" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#888" stopOpacity={0}/>
                </linearGradient>
                <linearGradient id="foreGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#7c3aed" stopOpacity={0.2}/>
                  <stop offset="95%" stopColor="#7c3aed" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
              <XAxis dataKey="date" tick={{ fontSize: 11 }} tickFormatter={d => d.slice(5)} interval="preserveStartEnd"/>
              <YAxis tick={{ fontSize: 11 }} domain={["auto","auto"]} tickFormatter={v => `${curr}${v}`}/>
              <Tooltip formatter={(v, n) => [`${curr}${v}`, n === "price" ? "Historical" : "Forecast"]}/>
              <ReferenceLine x={histData[histData.length - 1]?.date} stroke="#ccc" strokeDasharray="4 4" label={{ value: "Today", fontSize: 11 }}/>
              <Area type="monotone" dataKey="price"    stroke="#888"   strokeWidth={2} fill="url(#histGrad)" connectNulls/>
              <Area type="monotone" dataKey="forecast" stroke="#7c3aed" strokeWidth={2} strokeDasharray="5 5" fill="url(#foreGrad)" connectNulls/>
            </AreaChart>
          </ResponsiveContainer>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 8, marginTop: 20 }}>
            {predict.predictions.map((p, i) => (
              <div key={i} style={{
                background: "#f8f9fa", borderRadius: 10, padding: "10px 6px",
                textAlign: "center", border: "1px solid #e8e8e8",
              }}>
                <div style={{ fontSize: 11, color: "#888" }}>{p.date.slice(5)}</div>
                <div style={{ fontWeight: 700, fontSize: 13, marginTop: 4 }}>
                  {curr}{p.price.toLocaleString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Sentiment */}
      {tab === "sentiment" && sentiment && (
        <div style={{ background: "#fff", borderRadius: 16, padding: 24, border: "1px solid #e8e8e8" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <h2 style={{ fontSize: 16, fontWeight: 700 }}>Market Sentiment</h2>
            <SentimentBadge
              label={`Overall: ${sentiment.overall_label}`}
              color={sentiment.overall_color}
              score={sentiment.overall_score}
            />
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {sentiment.articles.map((a, i) => {
              const bg = a.color === "green" ? "#e6f9f4" : a.color === "red" ? "#fdeaea" : "#f0f0f0";
              const fg = a.color === "green" ? "#00b386" : a.color === "red" ? "#eb5757" : "#888";
              return (
                <a key={i} href={a.url} target="_blank" rel="noreferrer" style={{
                  display: "block", padding: 16, borderRadius: 12,
                  border: "1px solid #e8e8e8", background: "#fff",
                  transition: "box-shadow 0.2s",
                }}
                  onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 12px rgba(0,0,0,0.08)"}
                  onMouseLeave={e => e.currentTarget.style.boxShadow = "none"}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 600, fontSize: 14, marginBottom: 6 }}>{a.title}</div>
                      <div style={{ color: "#888", fontSize: 12 }}>{a.summary}</div>
                      <div style={{ color: "#aaa", fontSize: 11, marginTop: 6 }}>{a.publisher}</div>
                    </div>
                    <div style={{
                      background: bg, color: fg,
                      padding: "4px 10px", borderRadius: 20,
                      fontSize: 12, fontWeight: 600, whiteSpace: "nowrap",
                    }}>
                      {a.label}
                    </div>
                  </div>
                </a>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
